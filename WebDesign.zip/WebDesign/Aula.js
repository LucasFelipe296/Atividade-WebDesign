// Função para alterar a cor de uma linha
function alterarCorLinha(element) {
    element.style.backgroundColor = '#ffcccb'; // Cor de fundo alterada ao passar o mouse
}

// Função para restaurar a cor de uma linha
function restaurarCorLinha(element) {
    element.style.backgroundColor = ''; // Restaura a cor original
    
}

// Função para alterar a cor de uma linha ao clicar no botão (alterando a cor da linha 1, por exemplo)
function alterarCorLinhaBotao() {
    let linha = document.getElementById('linha1');
    linha.style.backgroundColor = '#cce7ff'; // Nova cor de fundo quando o botão for clicado
}

// Função para alterar a cor de uma linha por ID (passando o ID da linha)
function alterarCorLinhaPorId(id) {
    let linha = document.getElementById(id);
    linha.style.backgroundColor = '#d3ffcc'; // Nova cor de fundo quando o botão for clicado
}

// Função para capturar o nome do time e exibir no alert e no console
function capturarNomeTime() {
    let times = document.querySelectorAll("tr");
    times.forEach((linha) => {
        linha.addEventListener('click', function() {
            let nomeTime = this.querySelector("td:nth-child(3) a").innerHTML;
            alert("Time selecionado: " + nomeTime);
            console.log("Nome do time selecionado: " + nomeTime);
        });
    });
}

// Chama a função para capturar o nome do time ao carregar a página
window.onload = capturarNomeTime;
